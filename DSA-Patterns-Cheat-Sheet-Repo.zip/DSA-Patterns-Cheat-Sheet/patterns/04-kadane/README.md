# Kadane Pattern

See `../../data/dsa-patterns.csv` for the question/link tracker.

**Rule: one question daily.**
